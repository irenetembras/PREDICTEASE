# Initialization for gui module
