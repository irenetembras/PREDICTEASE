# Initialization for visualization module
