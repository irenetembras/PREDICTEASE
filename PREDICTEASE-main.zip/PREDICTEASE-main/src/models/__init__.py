# Initialization for models module
