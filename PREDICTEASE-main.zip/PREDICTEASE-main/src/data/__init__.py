# Initialization for data module
