# Initialization for data module
