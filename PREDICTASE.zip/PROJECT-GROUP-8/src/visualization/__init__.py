# Initialization for visualization module
