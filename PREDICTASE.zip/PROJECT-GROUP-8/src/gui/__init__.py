# Initialization for gui module
