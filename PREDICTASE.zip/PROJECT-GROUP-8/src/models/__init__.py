# Initialization for models module
